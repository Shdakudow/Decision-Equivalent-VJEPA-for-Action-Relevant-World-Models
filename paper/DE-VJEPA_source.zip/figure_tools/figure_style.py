"""Use the manuscript's Latin Modern Roman in every rebuilt figure.

PDFs use Cairo to embed the original OpenType fonts correctly. Font
registration is local to this process; no system fonts are installed.
"""
import ctypes
import ctypes.util
from pathlib import Path
import sys
import re

import matplotlib
from matplotlib import font_manager

FONT_DIR = Path(__file__).resolve().parent / 'fonts'


def configure_fonts():
    fonts = sorted(FONT_DIR.glob('*.otf'))
    if len(fonts) != 3:
        raise RuntimeError('The three bundled Latin Modern Roman fonts are required.')
    for font in fonts:
        font_manager.fontManager.addfont(str(font))

    math_dir = Path(matplotlib.get_data_path()) / 'fonts/ttf'
    math_fonts = [math_dir / name for name in ('cmr10.ttf', 'cmmi10.ttf', 'cmsy10.ttf', 'cmex10.ttf')]
    if sys.platform == 'darwin':
        # The macOS Cairo build uses Quartz: register in CoreText for this
        # process only. Neither the OS font folders nor user settings change.
        cf = ctypes.CDLL('/System/Library/Frameworks/CoreFoundation.framework/CoreFoundation')
        ct = ctypes.CDLL('/System/Library/Frameworks/CoreText.framework/CoreText')
        cf.CFURLCreateFromFileSystemRepresentation.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_long, ctypes.c_bool]
        cf.CFURLCreateFromFileSystemRepresentation.restype = ctypes.c_void_p
        cf.CFRelease.argtypes = [ctypes.c_void_p]
        ct.CTFontManagerRegisterFontsForURL.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.c_void_p]
        ct.CTFontManagerRegisterFontsForURL.restype = ctypes.c_bool
        for font in fonts + math_fonts:
            encoded = str(font).encode()
            url = cf.CFURLCreateFromFileSystemRepresentation(None, encoded, len(encoded), False)
            ct.CTFontManagerRegisterFontsForURL(url, 1, None)
            cf.CFRelease(url)
    else:
        _register_fontconfig(fonts + math_fonts)
    matplotlib.rcParams.update({
        'font.family': 'serif', 'font.serif': ['Latin Modern Roman'],
        'mathtext.fontset': 'cm', 'axes.unicode_minus': True,
        'pdf.fonttype': 42, 'ps.fonttype': 42,
    })


def _register_fontconfig(fonts):
    # Linux Cairo uses fontconfig rather than Matplotlib's font registry.
    library = ctypes.util.find_library('fontconfig')
    if library is None and Path('/opt/homebrew/lib/libfontconfig.1.dylib').exists():
        library = '/opt/homebrew/lib/libfontconfig.1.dylib'
    if library is None:
        raise RuntimeError('Install Cairo and fontconfig to rebuild the vector PDFs.')
    fc = ctypes.CDLL(library)
    fc.FcConfigAppFontAddFile.argtypes = [ctypes.c_void_p, ctypes.c_char_p]
    fc.FcConfigAppFontAddFile.restype = ctypes.c_int
    for font in fonts:
        if not fc.FcConfigAppFontAddFile(None, str(font).encode()):
            raise RuntimeError(f'Could not register figure font {font.name}')


def save_pdf(fig, path):
    """Keep text selectable and avoid treating OpenType CFF fonts as TrueType."""
    import cairocffi as cairo
    from matplotlib.backends import backend_cairo
    from matplotlib.ft2font import FT2Font

    original_show = cairo.Context.show_text
    original_args = backend_cairo._cairo_font_args_from_font_prop
    original_surface = cairo.PDFSurface

    class CompatiblePDFSurface(original_surface):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.restrict_to_version(cairo.PDF_VERSION_1_5)

    def show_without_space_glyphs(ctx, text):
        # Quartz otherwise creates Type 3 resources just for blank spaces.
        # Advancing the current point preserves the measured spacing.
        for run in re.findall(r'\s+|\S+', text):
            if run.isspace():
                dx, dy = ctx.text_extents(run)[4:6]
                ctx.rel_move_to(dx, dy)
            else:
                original_show(ctx, run)

    def exact_face(prop):
        # Quartz reliably resolves a face's PostScript name, including bold.
        filename = prop.fname if isinstance(prop, font_manager.FontEntry) else font_manager.findfont(prop)
        return FT2Font(filename).postscript_name, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_NORMAL

    try:
        cairo.Context.show_text = show_without_space_glyphs
        cairo.PDFSurface = CompatiblePDFSurface
        if sys.platform == 'darwin':
            backend_cairo._cairo_font_args_from_font_prop = exact_face
        fig.savefig(path, backend='cairo')
    finally:
        cairo.Context.show_text = original_show
        cairo.PDFSurface = original_surface
        backend_cairo._cairo_font_args_from_font_prop = original_args
