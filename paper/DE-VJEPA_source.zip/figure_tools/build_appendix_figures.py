"""Redraw the remaining legacy plots from original compact result CSVs.

Preserves their numerical inputs, loss-weight significance rings, heatmap
clipping, and planner error bars. No experiments or tests are run.
"""
from pathlib import Path
import json
import os

SOURCE = Path(__file__).resolve().parents[1]
os.environ.setdefault('MPLCONFIGDIR', '/private/tmp/devjepa-example-mpl')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from figure_style import configure_fonts, save_pdf

plt.rcParams.update({'font.size':8.5, 'axes.labelsize':8.5,
                     'axes.titlesize':9, 'legend.fontsize':7.5,
                     'xtick.labelsize':8, 'ytick.labelsize':8,
                     'axes.spines.top':False, 'axes.spines.right':False})
configure_fonts()
RESULTS = SOURCE / 'evidence/results'
PREVIEW = SOURCE.parent / 'qa/figure_previews'
PREVIEW.mkdir(parents=True, exist_ok=True)


def finish(fig, name):
    save_pdf(fig, SOURCE / 'figures' / (name + '.pdf'))
    fig.savefig(PREVIEW / (name + '.png'), dpi=200)
    plt.close(fig)


# Same rows, symlog scales and significance criterion as the original panel.
sweep = pd.read_csv(RESULTS / 'lambda_sweep_summary.csv')
clean = sweep[sweep['shift'] == 'clean']
fig, ax = plt.subplots(figsize=(4.8, 3.35))
fig.subplots_adjust(left=.16, right=.98, bottom=.19, top=.72)
for metric, label, color, marker in [('latent_mse','Latent MSE','#D55E00','s'),
                                     ('decision_kl','Decision KL','#0072B2','o'),
                                     ('action_mse','Action MSE','#009E73','^')]:
    part = clean[clean['metric'] == metric].sort_values('lambda')
    ax.plot(part['lambda'], part['relative_change_percent'], color=color,
            marker=marker, lw=1.5, ms=4.5, label=label)
    selected = part[part['paired_t_p'] < .05]
    ax.scatter(selected['lambda'], selected['relative_change_percent'], s=58,
               facecolors='none', edgecolors=color, lw=1)
ax.axhline(0, color='#667085', lw=.8)
ax.set_xscale('symlog',linthresh=1e-4); ax.set_yscale('symlog',linthresh=5)
ax.set_xticks([0,1e-4,1e-3,1e-2,1e-1], ['0',r'$10^{-4}$',r'$10^{-3}$',r'$10^{-2}$',r'$10^{-1}$'])
ax.set_yticks([-20,-10,0,10,20,50,100], ['−20','−10','0','10','20','50','100'])
ax.set_xlim(-5e-6,.13); ax.set_ylim(-22,130)
ax.set(xlabel=r'Decision weight $\lambda$',ylabel='Change vs. latent-only (%)')
ax.set_title('(a) Fidelity is tunable',loc='left',fontweight='bold',pad=32)
ax.legend(loc='lower center',bbox_to_anchor=(.5,1.02),ncol=3,frameon=False,
           columnspacing=.9,handlelength=1.3,fontsize=7.5)
ax.grid(axis='y',color='#E7E9EC',lw=.6)
finish(fig,'loss_weight_v2')

# Same 10 x 4 cells and rounded numbers as the original heatmap.
data = pd.read_csv(RESULTS / 'cross_dataset_comparison_summary.csv')
data = data[data['metric'] == 'decision_kl']
methods = ['persistence','linear_dynamics','no_action_vjepa','cosine_jepa',
           'action_mse','bjepa','de_vjepa','de_bjepa','random_policy_kl','weak_policy_kl']
labels = ['Persistence','Linear','No action','Cosine','Action mean','BJEPA',
          'DE-VJEPA','DE-BJEPA','Random KL','Weak-BC KL']
shifts = ['clean','brightness','blur','desaturation']
fig, axes = plt.subplots(1,2,figsize=(6.5,3.5),sharey=True)
fig.subplots_adjust(left=.18,right=.88,bottom=.20,top=.83,wspace=.09)
matrices = {}
for ax, dataset, title in zip(axes,['metaworld-5','lerobot-pusht'],['MetaWorld-5','PushT']):
    part = data[data['dataset'] == dataset]
    matrix = np.empty((10,4))
    for j,shift in enumerate(shifts):
        baseline = part[(part['method']=='vjepa') & (part['shift']==shift)]['mean'].item()
        for i,method in enumerate(methods):
            value = part[(part['method']==method) & (part['shift']==shift)]['mean'].item()
            matrix[i,j] = 100*(value-baseline)/baseline
    matrices[dataset] = matrix.tolist()
    clipped = np.clip(matrix,-50,50)
    im=ax.imshow(clipped,cmap='RdBu_r',vmin=-50,vmax=50,aspect='auto')
    for i in range(10):
        for j in range(4):
            value=matrix[i,j]
            text='0' if abs(value)<.5 else f'{value:+.0f}'
            ax.text(j,i,text,ha='center',va='center',fontsize=7.5,
                     color='white' if abs(clipped[i,j])>28 else 'black')
    ax.set_xticks(range(4),['Clean','Bright.','Blur','Desat.'],rotation=25)
    ax.set_title(title,fontweight='bold',pad=8)
    ax.set_xlabel('Decision KL change vs. VJEPA (%)',fontsize=8)
axes[0].set_yticks(range(10),labels)
cax=fig.add_axes([.91,.20,.018,.63]); fig.colorbar(im,cax=cax).set_label('lower is better',fontsize=8)
fig.suptitle('Extended baseline matrix: independent decision KL',fontsize=10,fontweight='bold',y=.97)
finish(fig,'baseline_matrix_v2')

# Same ALL-task means and standard errors as the original combined panel.
data=pd.read_csv(RESULTS/'planner_ablation_summary.csv')
data=data[data['task']=='ALL']
conditions=['clean','brightness','background_shift']
settings=[('bc_only','bc_only','BC only','#4B5563'),
 ('bc_plus_vjepa','entropy_score','VJEPA + entropy','#7a8a98'),
 ('bc_plus_de_vjepa','entropy_score','DE-VJEPA + entropy','#3b6ea5'),
 ('bc_plus_vjepa','decision_consistency_score','VJEPA + decision','#b5651d'),
 ('bc_plus_de_vjepa','decision_consistency_score','DE-VJEPA + decision','#d59a4d'),
 ('bc_plus_vjepa','action_mean_consistency_score','VJEPA + action mean','#5c8a5c'),
 ('bc_plus_de_vjepa','action_mean_consistency_score','DE-VJEPA + action mean','#88b888'),
 ('bc_plus_vjepa','random_candidate_control','VJEPA + random','#666666'),
 ('bc_plus_de_vjepa','random_candidate_control','DE-VJEPA + random','#aaaaaa')]
fig,axes=plt.subplots(2,1,figsize=(6.5,6.5))
fig.subplots_adjust(left=.12,right=.985,bottom=.18,top=.94,hspace=.48)
width=.8/len(settings); x=np.arange(3); outputs=[]
for ax,mean_col,err_col,ylabel,title in [
 (axes[0],'success_mean','success_stderr','Episode success rate','(a) Planner-ablation success rates'),
 (axes[1],'mean_decision_kl_mean','mean_decision_kl_stderr','Online decision KL','(b) Planner-ablation online decision KL')]:
    for i,(method,score,label,color) in enumerate(settings):
        rows=[data[(data['method']==method)&(data['planner_score']==score)&(data['visual_condition']==c)].iloc[0] for c in conditions]
        means=np.array([r[mean_col] for r in rows]); errs=np.array([r[err_col] for r in rows])
        # Direct BC has no predicted latent and hence no model decision KL.
        ax.bar(x+(i-4)*width,means,width,yerr=errs,capsize=1.5,label=label,
                color=color,edgecolor='white',lw=.4,error_kw={'elinewidth':.7})
        outputs.append({'metric':mean_col,'method':method,'score':score,
                        'means':[None if not np.isfinite(v) else float(v) for v in means],
                        'stderr':[None if not np.isfinite(v) else float(v) for v in errs]})
    ax.set_xticks(x,['Clean','Brightness','Background shift'])
    ax.set_ylabel(ylabel); ax.set_title(title,loc='left',fontweight='bold',pad=9)
    ax.set_axisbelow(True); ax.grid(axis='y',color='#E7E9EC',lw=.6)
handles,labels=axes[0].get_legend_handles_labels()
fig.legend(handles,labels,loc='lower center',bbox_to_anchor=(.52,.015),ncol=3,
            frameon=False,fontsize=7.2,columnspacing=1.4,handlelength=1.5)
finish(fig,'planner_ablation_v2')
(SOURCE/'figure_data/appendix_plot_sources.json').write_text(json.dumps({
 'loss_weight_v2':'lambda_sweep_summary.csv: clean rows, relative_change_percent, paired_t_p < .05 rings',
 'baseline_matrix_v2':{'source':'cross_dataset_comparison_summary.csv: decision_kl means, relative to vjepa','matrices':matrices},
 'planner_ablation_v2':{'source':'planner_ablation_summary.csv: ALL rows, means and standard errors','plotted_values':outputs},
 'note':'Original compact CSVs unchanged. Same numerical inputs and conventions as original plotting code; typography and layout updated only.'
},indent=2)+'\n')
print('Rebuilt three appendix plots with manuscript fonts.')
