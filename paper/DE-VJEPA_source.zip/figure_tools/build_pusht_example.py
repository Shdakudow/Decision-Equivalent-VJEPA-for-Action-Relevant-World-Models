"""Rebuild the real PushT example from saved frames and one-transition outputs.

No training, inference, generated images, or new statistical tests are run.
"""
import json
import os
from pathlib import Path

SOURCE = Path(__file__).resolve().parents[1]
os.environ.setdefault('MPLCONFIGDIR', '/private/tmp/devjepa-example-mpl')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Ellipse, Rectangle
import numpy as np
from PIL import Image
from figure_style import configure_fonts, save_pdf

plt.rcParams.update({'font.size': 8,
                     'axes.titlesize': 8, 'pdf.fonttype': 42, 'ps.fonttype': 42})
configure_fonts()
data = json.loads((SOURCE / 'figure_data/pusht_example.json').read_text())
selection = data['selection']
current = np.asarray(Image.open(SOURCE / 'figures/pusht_example/current.png'))
future = np.asarray(Image.open(SOURCE / 'figures/pusht_example/next.png'))
BLUE, TEAL, DARK, GRAY = '#0072B2', '#009E73', '#222B36', '#667085'

fig = plt.figure(figsize=(6.5, 3.55), facecolor='white')
axes = [fig.add_axes(rect) for rect in [(0.015, .38, .29, .53),
                                      (.345, .38, .29, .53),
                                      (.675, .38, .31, .53)]]
for ax, image, title in zip(axes, [current, future, future],
                           ['(a) Input frame + action',
                            '(b) Observed next frame',
                            '(c) Policy readout (zoom)']):
    ax.imshow(image, interpolation='nearest', extent=(0, 96, 96, 0),
              alpha=.38 if ax is axes[2] else 1)
    ax.set_title(title, loc='left', pad=8, fontweight='bold')
    ax.set_xticks([]); ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_color('#D0D5DD'); spine.set_linewidth(.7)
    ax.set_xlim(3, 78); ax.set_ylim(84, 9)

pusher = np.array(selection['pusher_t_workspace']) * 96 / 512
action = np.array(selection['action_t_workspace']) * 96 / 512
axes[0].plot(*action, marker='x', color='#D55E00', ms=7, mew=1.3)
axes[0].annotate(r'Recorded $a_t$', xy=action, xytext=(43, 74), fontsize=7.5,
                 ha='left', color='#A33D00',
                 arrowprops={'arrowstyle': '->', 'color': '#D55E00', 'lw': .9,
                             'connectionstyle': 'arc3,rad=-.12'})
axes[0].text(.03, .96, f'Frame {selection["frame"]}', transform=axes[0].transAxes,
             va='top', fontsize=7, color=GRAY)
axes[1].text(.03, .96, f'Frame {selection["next_frame"]}  (+0.1 s)',
             transform=axes[1].transAxes, va='top', fontsize=7, color=GRAY)

points = [('Observed future', data['observed_future_policy'], DARK, '+'),
          ('VJEPA', data['models']['VJEPA'], BLUE, 'o'),
          ('DE-VJEPA', data['models']['DE-VJEPA'], TEAL, 's')]
bounds = []
for label, record, color, marker in points:
    mean, std = np.array(record['mean_image']), np.array(record['std_image'])
    bounds.extend([mean - std, mean + std])
    axes[2].add_patch(Ellipse(mean, 2*std[0], 2*std[1], fill=False,
                            edgecolor=color, lw=1.1, ls='--' if marker=='+' else '-'))
    axes[2].plot(*mean, marker=marker, ms=7 if marker=='+' else 4.5,
                 mew=1.4 if marker=='+' else .9, color=color,
                 mfc='white' if marker!='+' else color, zorder=5)
bounds = np.array(bounds)
mid = (bounds.min(0) + bounds.max(0)) / 2
half = max(float(np.ptp(bounds, axis=0).max()) * .64, 5)
axes[2].set_xlim(mid[0]-half, mid[0]+half)
axes[2].set_ylim(mid[1]+half, mid[1]-half)
axes[1].add_patch(Rectangle(mid-half, 2*half, 2*half, fill=False,
                            edgecolor=GRAY, lw=.8, ls='--'))
axes[2].text(.04, .04, 'Means + 1-SD contours', transform=axes[2].transAxes,
             fontsize=6.8, color=DARK,
             bbox={'facecolor':'white', 'alpha':.85, 'edgecolor':'none', 'pad':1.5})

handles = [Line2D([], [], color=c, marker=m, lw=1, label=label,
                  markerfacecolor='white' if m!='+' else c, markersize=5)
           for label, _, c, m in points]
fig.legend(handles=handles, loc='center', bbox_to_anchor=(.5,.315),
           ncol=3, frameon=False, fontsize=8, handlelength=1.6, columnspacing=2.5)

# Keep numeric labels outside the plots and away from image annotations.
fig.text(.065, .225, 'This transition only', color=GRAY, fontsize=7.5)
fig.text(.59, .225, 'VJEPA', color=BLUE, fontsize=8, ha='center', fontweight='bold')
fig.text(.84, .225, 'DE-VJEPA', color=TEAL, fontsize=8, ha='center', fontweight='bold')
for y, label, key, fmt in [(.158, 'Decision KL', 'decision_kl', '.3f'),
                           (.092, 'Action-mean MSE', 'action_mse', '.4f')]:
    fig.text(.065, y, label + '  (lower is better)', fontsize=7.5)
    for x, name in [(.59, 'VJEPA'), (.84, 'DE-VJEPA')]:
        fig.text(x, y, format(data['models'][name][key], fmt), ha='center', fontsize=8)

save_pdf(fig, SOURCE / 'figures/pusht_transition_example.pdf')
preview = SOURCE.parent / 'qa/figure_previews'
preview.mkdir(parents=True, exist_ok=True)
fig.savefig(preview / 'pusht_transition_example.png', dpi=220)
plt.close(fig)
