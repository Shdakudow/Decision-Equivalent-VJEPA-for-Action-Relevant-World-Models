"""Build vector plots from values already reported in the manuscript.

No experiments or new statistical tests are run. Most values are parsed from
the TeX tables, so changes to the reported tables propagate to the plots.
The four paired success intervals below are transcribed from reported prose.
"""
from pathlib import Path
import argparse
import json
import os
import re

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--only', choices=[
    'offline_overview_v2', 'policy_geometry_v2', 'closed_loop_v2',
    'multistep_v2', 'cem_progress_v2', 'ablation_summary_v2',
], help='Rebuild only the selected plot; preserve the other plot files.')
args = parser.parse_args()

SOURCE = Path(__file__).resolve().parents[1]
os.environ.setdefault('MPLCONFIGDIR', str(SOURCE / 'figure_tools/.mplconfig'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from figure_style import configure_fonts, save_pdf

FIGURES = SOURCE / 'figures'
DATA = SOURCE / 'figure_data'
PREVIEWS = SOURCE.parent / 'qa/figure_previews'
PREVIEWS.mkdir(parents=True, exist_ok=True)
TEXT = '\n'.join(p.read_text() for folder in ['sections', 'appendices']
                 for p in sorted((SOURCE / folder).glob('*.tex')))
plt.rcParams.update({
    'font.size': 8.5,
    'axes.titlesize': 9, 'axes.labelsize': 8.5,
    'xtick.labelsize': 8, 'ytick.labelsize': 8,
    'legend.fontsize': 8, 'axes.spines.top': False,
    'axes.spines.right': False, 'axes.linewidth': .7,
    'lines.linewidth': 1.6, 'lines.markersize': 4.5,
    'pdf.fonttype': 42, 'ps.fonttype': 42, 'savefig.facecolor': 'white',
})
configure_fonts()
GRAY, BLUE, TEAL, ORANGE = '#667085', '#0072B2', '#009E73', '#D55E00'


def clean(value):
    return re.sub(r'\\[A-Za-z]+', '', value).replace('{', '').replace('}', '').replace('$', '').strip()


def numbers(value):
    return [float(x) for x in re.findall(r'[+-]?(?:\d+(?:\.\d*)?|\.\d+)', value)]


def table_rows(label):
    block = next(m[1] for m in re.finditer(r'\\begin\{table\}(.*?)\\end\{table\}', TEXT, re.S)
                 if r'\label{' + label + '}' in m[1])
    body = re.search(r'\\begin\{tabular\}(.*?)\\end\{tabular\}', block, re.S)[1]
    body = body[body.index(r'\midrule') + len(r'\midrule'):]
    body = re.sub(r'\\(?:toprule|midrule|bottomrule)', '', body)
    return [[cell.strip() for cell in row.split('&')]
            for row in re.split(r'\\\\\s*', body) if '&' in row]


def finish(fig, name):
    if args.only and name != args.only:
        plt.close(fig)
        return
    save_pdf(fig, FIGURES / f'{name}.pdf')
    fig.savefig(PREVIEWS / f'{name}.png', dpi=180)
    plt.close(fig)


def tidy(ax, axis='y'):
    ax.set_axisbelow(True)
    ax.grid(axis=axis, color='#E7E9EC', linewidth=.6)


cross = []
dataset = None
for row in table_rows('tab:cross-dataset'):
    dataset = clean(row[0]) or dataset
    cross.append({'dataset': dataset, 'condition': clean(row[1]),
                  'latent_change': numbers(row[2])[0], 'decision_change': numbers(row[3])[0],
                  'action_change': numbers(row[4])[0]})

geometry = [{'reference': clean(r[0]), 'clean': numbers(r[1])[0],
             'brightness': numbers(r[2])[0]} for r in table_rows('tab:geometry-results')]
multi = [{'method': clean(r[0]), 'horizon': int(numbers(r[1])[0]),
          'latent_mse': numbers(r[2])[0], 'decision_kl': numbers(r[3])[0],
          'action_mse': numbers(r[4])[0]} for r in table_rows('tab:multistep-final')]
core, condition = [], None
for r in table_rows('tab:complete-core-results'):
    condition = clean(r[0]) or condition
    core.append({'condition': condition, 'method': clean(r[1]),
                 'latent_mse': numbers(r[2])[0], 'decision_kl': numbers(r[3])[0]})

closed = [{'method': clean(r[0]), 'conditions': [numbers(cell) for cell in r[1:4]]}
          for r in table_rows('tab:closed-loop-rollout-main')]
cem = [{'method': clean(r[0]), 'horizon': int(numbers(r[1])[0]) if numbers(r[1]) else None,
        'success': [numbers(cell)[0] for cell in r[2:6]]}
       for r in table_rows('tab:cem-progress-key')]

# These are already reported intervals, not intervals recomputed from plotted means.
paired = [
    {'label': 'One-step: all', 'mean': 1.30, 'low': -2.41, 'high': 4.44, 'p': .473},
    {'label': 'One-step: brightness', 'mean': 2.78, 'low': 0., 'high': 6.67, 'p': .179},
    {'label': 'CEM H=3: all', 'mean': 5.56, 'low': -.37, 'high': 12.59, 'p': .113},
    {'label': 'CEM H=3: brightness', 'mean': 13.33, 'low': 2.22, 'high': 24.44, 'p': .073},
]

# Main result: separate legend and data regions; no text is placed on bars.
fig = plt.figure(figsize=(6.5, 3.0))
gs = fig.add_gridspec(1, 2, width_ratios=[1, 1.22], left=.10, right=.985,
                     bottom=.19, top=.80, wspace=.55)
ax, bx = fig.add_subplot(gs[0]), fig.add_subplot(gs[1])
base = next(x for x in core if x['condition'] == 'Clean' and x['method'] == 'VJEPA')
point = next(x for x in core if x['condition'] == 'Clean' and x['method'] == 'DE-VJEPA')
x, y = [100 * (point[key] / base[key] - 1) for key in ['latent_mse', 'decision_kl']]
ax.axhspan(-28, 0, facecolor=BLUE, alpha=.035, zorder=0)
ax.plot([0,x], [0,0], ls=':', color=ORANGE, lw=1.3)
ax.plot([x,x], [0,y], ls=':', color=BLUE, lw=1.3)
ax.plot(0, 0, 'o', color=GRAY, markersize=5.5)
ax.plot(x, y, 'o', color=BLUE, markersize=7)
ax.annotate('VJEPA', (0,0), xytext=(-1,7), textcoords='offset points', fontsize=8)
ax.annotate('DE-VJEPA', (x,y), xytext=(-4,-14), ha='right', textcoords='offset points', fontsize=8)
ax.text(.97, .95, f'+{x:.1f}% latent MSE', transform=ax.transAxes,
        ha='right', va='top', color=ORANGE, fontsize=8,
        bbox=dict(facecolor='white', edgecolor='none', pad=1.3))
ax.text(x+2, y/2, f'{y:.1f}%\ndecision KL', va='center', color=BLUE, fontsize=8)
ax.axhline(0, color='#98A2B3', lw=.8); ax.axvline(0, color='#98A2B3', lw=.8)
ax.set(xlim=(-3, 32), ylim=(-28, 10), xticks=[0,10,20,30], xlabel='Latent MSE change (%)', ylabel='Decision KL change (%)')
ax.set_title('(a) Two metrics, two rankings', loc='left', pad=12); tidy(ax)
conditions = ['Clean', 'Brightness', 'Blur', 'Desaturation']
for data, shift, color, marker in [('MetaWorld-5', -.14, BLUE, 'o'), ('PushT', .14, TEAL, 's')]:
    values = [next(r['decision_change'] for r in cross if r['dataset'] == data and r['condition'] == c)
              for c in conditions]
    bx.plot(values, np.arange(4) + shift, linestyle='', marker=marker, color=color, label=data)
    for value, y in zip(values, np.arange(4) + shift):
        bx.annotate(f'{value:+.1f}', (value, y), xytext=(-4, -1) if shift < 0 else (4, 0),
                    textcoords='offset points', ha='right' if shift < 0 else 'left', va='center',
                    fontsize=7, bbox=dict(facecolor='white', edgecolor='none', pad=.3))
bx.axvspan(-33, 0, facecolor=TEAL, alpha=.035, zorder=0)
bx.axvspan(0, 13, facecolor=ORANGE, alpha=.035, zorder=0)
bx.axvline(0, color='#98A2B3', lw=.8)
bx.set(yticks=np.arange(4), yticklabels=conditions, ylim=(3.45, -.55), xlim=(-33, 13),
       xlabel='Decision KL change (%)')
bx.set_title('(b) Lower KL in 7/8 conditions', loc='left', pad=12); tidy(bx, 'x')
bx.legend(loc='lower center', bbox_to_anchor=(.5, 1.11), ncol=2, frameon=False,
          columnspacing=.8, handletextpad=.3, fontsize=7.5)
finish(fig, 'offline_overview_v2')

# Reference-policy ablation: legend is outside the axes and values sit below bar ends.
fig, ax = plt.subplots(figsize=(4.8, 2.8))
fig.subplots_adjust(left=.15, right=.98, bottom=.20, top=.77)
x = np.arange(3); width = .34
for key, offset, color, label in [('clean', -width/2, GRAY, 'Clean'),
                                  ('brightness', width/2, TEAL, 'Brightness')]:
    values = [r[key] for r in geometry]
    ax.bar(x + offset, values, width, color=color, label=label)
    for xx, val in zip(x + offset, values):
        ax.text(xx, val - .8, f'{val:g}', ha='center', va='top', fontsize=7.5)
ax.axhline(0, color='#98A2B3', lw=.8)
ax.set(xticks=x, xticklabels=['Random', 'Weak BC', 'Strong BC'], ylim=(-29, 2),
       ylabel='Decision KL change (%)')
ax.legend(loc='lower center', bbox_to_anchor=(.5, 1.06), ncol=2, frameon=False)
tidy(ax); finish(fig, 'policy_geometry_v2')

# Closed-loop intervals are the published episode-bootstrap CIs in the table.
fig, ax = plt.subplots(figsize=(6.5, 3.2))
fig.subplots_adjust(left=.11, right=.985, bottom=.23, top=.79)
positions = np.arange(3); width = .23
for i, (row, color) in enumerate(zip(closed, ['#344054', GRAY, BLUE])):
    means, lows, highs = np.asarray(row['conditions']).T
    ax.bar(positions + (i-1)*width, means, width, color=color, label=row['method'],
           yerr=[means-lows, highs-means], capsize=2,
           error_kw={'elinewidth': .8, 'capthick': .8})
ax.set(xticks=positions, xticklabels=['Clean', 'Brightness', 'Background shift'],
       ylim=(0, 95), ylabel='Episode success (%)')
ax.legend(loc='lower center', bbox_to_anchor=(.5, 1.05), ncol=3, frameon=False)
overall = paired[0]
fig.text(.55, .025,
         f'Overall paired difference: +{overall["mean"]:.2f} points; '
         f'95% CI [{overall["low"]:.2f}, {overall["high"]:.2f}]',
         ha='center', fontsize=7.5, color='#344054')
tidy(ax); finish(fig, 'closed_loop_v2')

# Multi-step curves use the reported table, including its exact latent-MSE values.
fig, axes = plt.subplots(1, 2, figsize=(6.5, 2.8))
fig.subplots_adjust(left=.10, right=.98, bottom=.20, top=.80, wspace=.40)
for ax, key, title, ylabel in zip(axes, ['decision_kl', 'latent_mse'],
                                ['(a) Decision error', '(b) Latent error'], ['Decision KL', 'Latent MSE']):
    for method, color, marker in [('VJEPA', GRAY, 'o'), ('DE-VJEPA', BLUE, 's')]:
        points = sorted((r for r in multi if r['method'] == method), key=lambda r:r['horizon'])
        ax.plot([r['horizon'] for r in points], [r[key] for r in points], marker=marker,
                color=color, label=method)
    ax.set(xticks=[1,3,5], xlabel='Prediction horizon K', ylabel=ylabel)
    ax.set_title(title, loc='left', pad=9); tidy(ax)
fig.legend(*axes[0].get_legend_handles_labels(), loc='upper center', ncol=2, frameon=False)
finish(fig, 'multistep_v2')

# Three conditions are shown separately; no unrecovered error bars are recreated.
fig, axes = plt.subplots(1, 3, figsize=(6.5, 2.65), sharex=True)
fig.subplots_adjust(left=.08, right=.985, bottom=.20, top=.75, wspace=.36)
for col, (ax, condition) in enumerate(zip(axes, ['Clean', 'Brightness', 'Background'])):
    for method, color, marker in [('VJEPA+CEM', GRAY, 'o'), ('DE-VJEPA+CEM', BLUE, 's')]:
        rows = sorted((r for r in cem if r['method'] == method), key=lambda r:r['horizon'])
        ax.plot([r['horizon'] for r in rows], [r['success'][col] for r in rows],
                marker=marker, color=color, label=method)
    bc = next(r['success'][col] for r in cem if r['method'] == 'BC only')
    ax.axhline(bc, color='#344054', ls='--', lw=1, label='BC only')
    ax.set_title(f'({chr(97+col)}) {condition}', loc='left', pad=9)
    ax.set(xticks=[1,3,5], xlabel='Planning horizon H'); tidy(ax)
    if col == 0: ax.set_ylabel('Success (%)')
    if col == 0: ax.set_ylim(0, 100)
    else: ax.set_ylim(0, 40)
fig.legend(*axes[0].get_legend_handles_labels(), loc='upper center', ncol=3,
           frameon=False, fontsize=7.5, columnspacing=1.2)
finish(fig, 'cem_progress_v2')

# Supplemental comparison and interval plot. Leave space for labels outside marks.
fig, (ax, bx) = plt.subplots(1, 2, figsize=(6.5, 2.8), gridspec_kw={'width_ratios':[.75, 1.5]})
fig.subplots_adjust(left=.09, right=.98, bottom=.23, top=.78, wspace=.85)
selected = {clean(r[0]): numbers(r[2])[0] for r in table_rows('tab:method-comparison') if numbers(r[2])}
ax.bar([0,1], [selected['DE-VJEPA'], selected['Action mean']], color=[BLUE, GRAY], width=.55)
for x, value in enumerate([selected['DE-VJEPA'], selected['Action mean']]):
    ax.text(x, value-1, f'{value:g}', ha='center', va='top', fontsize=8)
ax.axhline(0, color='#98A2B3', lw=.8)
ax.set(xticks=[0,1], xticklabels=['Policy KL', 'Mean match'], ylim=(-27, 2),
       ylabel='Clean decision KL change (%)')
ax.set_title('(b) Pilot loss comparison', loc='left', pad=14); tidy(ax)
for i, row in enumerate(paired):
    bx.errorbar(row['mean'], i, xerr=[[row['mean']-row['low']], [row['high']-row['mean']]],
                fmt='o', color=BLUE, ecolor=GRAY, capsize=2, elinewidth=1)
    bx.text(29, i, f'{row["p"]:.3f}', va='center', fontsize=7.5)
bx.axvline(0, color='#98A2B3', lw=.8)
bx.set(yticks=range(4), yticklabels=[r['label'] for r in paired], ylim=(3.5,-.5),
       xlim=(-5, 36), xticks=[0,10,20], xlabel='Success difference (points)')
bx.text(29, -.76, 'p', fontstyle='italic', fontsize=8)
bx.set_title('(c) Paired control effects', loc='left', pad=14); tidy(bx, 'x')
finish(fig, 'ablation_summary_v2')

DATA.mkdir(exist_ok=True)
data = {'cross_dataset': cross, 'reference_geometry': geometry, 'multistep': multi,
        'core_comparison': core, 'closed_loop': closed, 'cem': cem, 'paired_intervals': paired}
(DATA/'reported_values.json').write_text(json.dumps(data, indent=2)+'\n')
sources = {
    'offline_overview_v2': ['tab:complete-core-results', 'tab:cross-dataset'],
    'policy_geometry_v2': ['tab:geometry-results'],
    'closed_loop_v2': ['tab:closed-loop-rollout-main; reported 95% episode-bootstrap CIs'],
    'multistep_v2': ['tab:multistep-final'],
    'cem_progress_v2': ['tab:cem-progress-key; means only'],
    'ablation_summary_v2': ['tab:method-comparison',
        'appendices/c_closed_loop.tex: reported one-step paired differences and CIs',
        'appendices/e_progress_planning.tex: reported H=3 CEM paired differences and CIs'],
    'note': 'Redrawn from reported manuscript values; original compact summaries are included. No raw episode/sample files used; no experiments or statistical tests rerun.',
}
(DATA/'plot_sources.json').write_text(json.dumps(sources, indent=2)+'\n')
print(f'Wrote {args.only or "six vector plots"}, preview(s), and reported-value provenance files.')
