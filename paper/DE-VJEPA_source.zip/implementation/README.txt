Released implementation supplied for source inspection

src/, configs/, scripts/, tests/, and pyproject.toml are unmodified copies
from the original release. RELEASE_CHECKSUMS.csv records their hashes.
This README and audit_training_path.py are new documentation/audit tools.
The source package's evidence/results/ contains the 53 original compact
result CSVs, unchanged. The original raw run outputs are not included.

The retained VJEPA, DE-VJEPA, BJEPA and DE-BJEPA labels identify release
conditions. They do not establish that the implementation optimizes the
published Variational JEPA objective.

ACTUAL TRAINING PATH

train_predictor.py computes both posterior-conditioned and target-free
forward passes. It supplies prior_result.predicted to predictor_loss with
target=None and sample=False in that forward pass. models.py therefore
sets the auxiliary input h to zero. The posterior-conditioned prediction
is not scored. Only posterior_mean and posterior_logvar from that branch
enter a separate beta-weighted posterior KL. The posterior network receives
no prediction/policy-loss gradients; the task embedding is shared.

The VJEPA-labelled baseline uses latent MSE plus posterior KL. Its hybrid
variant adds lambda times the frozen reference policy's forward KL.
The BJEPA-labelled variants instead use the product-of-experts Gaussian
NLL, also evaluated with the auxiliary input fixed to zero.

AUDIT WITHOUT TRAINING

From this folder:
  python3 audit_training_path.py

Requires PyTorch, NumPy, PyYAML, and tqdm (all listed by the released project).
The audit checks the source hashes and uses one synthetic forward/backward
calculation. It takes no optimizer steps and requires no dataset or GPU.
It demonstrates loss connectivity; it does not verify historical results.

PROVENANCE LIMIT

The original release co-locates these files and the compact CSVs. Available
repository history contains only one training-code revision. Original run
logs/checkpoints linking a particular execution to a source revision were
not recovered. A matching release manifest proves file association and
integrity, not historical execution or independent reproduction.

The source is supplied in its original state for transparency. Archived
scripts may refer to large raw datasets and outputs excluded from the
release, and to its original repository layout. They are not invoked by
the dependency audit or by manuscript/figure builds. Any independent rerun
must record its own environment, code, data, and checkpoint provenance.
