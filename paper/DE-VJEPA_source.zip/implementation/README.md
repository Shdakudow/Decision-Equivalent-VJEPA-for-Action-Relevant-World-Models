# Released implementation

See [README.txt](README.txt) for the actual training paths, the source-only
dependency audit, and the limits of the historical run provenance.

The model names in this archived code are release identifiers. The revised
manuscript does not claim that it optimizes the full Variational JEPA bound.
