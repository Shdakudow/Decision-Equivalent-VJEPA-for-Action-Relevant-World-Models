Original compact result evidence

The 53 CSV files in results/ are unmodified copies from the original project
release. They contain reported aggregates, paired comparisons, statistics,
validation results, and training manifests. They are not reconstructed from
the manuscript or figures.

The folder includes smoke tests and an explicitly invalid PushT action-scale
run. These files are retained for auditability and must not be substituted
for the primary-study outputs.

Primary evidence files include:
  cross_method_metaworld_paired.csv
  cross_method_pusht_paired.csv
  vjepa_bjepa_de_comparison_summary.csv
  closed_loop_rollout_summary.csv
  closed_loop_rollout_statistics.csv
  multistep_diagnostic_summary.csv
  planner_ablation_summary.csv
  planner_ablation_statistics.csv
  cem_mpc_progress512_summary.csv
  cem_mpc_progress512_statistics.csv

Important interpretation details:

The generic cross-method summary CSVs use persistence for their baseline
percentage column. To compare DE-VJEPA with VJEPA, use the paired file with
candidate=de_vjepa and baseline=vjepa, or compute the ratio of their means.

The multi-step summary has one row per method, task, and horizon. The revised
paper averages the tasks equally. The original plotting script instead used
sample counts as weights, explaining the older plot/table difference.

The closed-loop summary CSVs include both task-level rows and rows with
task=ALL. Do not pool those two levels as if they were disjoint observations.

The original release excludes large raw episode/sample CSVs, datasets, and
checkpoints. These compact outputs support aggregate audits; they do not
constitute an independent reproduction of model training or evaluation.
