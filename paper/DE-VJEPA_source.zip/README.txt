Decision-Equivalent Latent Prediction — TMLR visual-example attempt

BUILD

Compile from this directory:
  tectonic -k --keep-logs main.tex

Alternatively, run pdfLaTeX at least twice, until references are resolved:
  pdflatex main.tex
  pdflatex main.tex

The bibliography is inline in references.tex. BibTeX is not required.

EDIT

main.tex contains the package imports, title, and order of the input files.
Edit the content files directly; no conversion script regenerates them.

sections/00_abstract.tex              Abstract
sections/01_introduction.tex          Motivation, benchmark context, main findings
sections/02_background.tex            Essential background and method positioning
sections/03_prediction_action_gap.tex Method overview fragment (included by 04)
sections/04_method.tex                Evaluated hybrid loss
sections/06_experiments.tex           Results, pilot ablations, control tests
sections/07_limitations.tex           Limits of the evidence
sections/08_discussion.tex            Interpretation and follow-up questions
sections/09_conclusion.tex            Main conclusion
sections/10_disclosures.tex           Full artifact statement, included in Appendix B
references.tex                       Bibliography
appendices/                          Detailed results, protocols, proposals, proof
figures/                             Diagram, vector plots, original images

FIGURE SOURCES

figures/decision_intuition.tex is an editable conceptual grasping illustration.
Its observed/predicted scenes and one-dimensional policy densities are
conceptual examples, not experimental outputs or decoded latent predictions.
All panels use the same frozen policy; dashed curves repeat the target
policy density. The shared band denotes separate applications of one policy.
figures/methodology.tex shows the released deterministic h=0 prediction
path and a separate posterior KL branch; there is no posterior-sample
arrow into the predictor loss.
figures/experimental_protocol.tex shows the episode split, training stages,
and separate offline-prediction and closed-loop-control evaluations.
All three diagrams use TikZ and the manuscript fonts; main.tex builds them
automatically. Update protocol labels together with the setup text and
Appendix B when the experimental design changes.

Ten plots, including the PushT example and three redrawn appendix plots,
are supplied as vector PDFs with embedded Latin Modern Roman fonts.
Their legends are outside the data area. To rebuild them, install Python,
Matplotlib, NumPy, Pandas, Pillow, cairocffi, and Cairo, then run from this directory:
  python3 figure_tools/build_figures.py
  python3 figure_tools/build_appendix_figures.py
  python3 figure_tools/build_pusht_example.py

To rebuild only the main result plot:
  python3 figure_tools/build_figures.py --only offline_overview_v2

The plotting script reads the reported TeX tables and saves the extracted
values to figure_data/reported_values.json. figure_data/plot_sources.json
records the source tables or prose for each plot. It does not use recovered
raw experimental data and does not run new statistical tests.

The original PNG files remain unchanged for provenance. The revised paper
uses vector PDFs for all charts. The three remaining original raster panels
were redrawn from the recovered compact CSVs with unchanged numerical inputs,
significance rings, heatmap clipping, and planner standard errors. The actual
PushT observations remain unmodified raster images inside a vector figure.

The original plotting code weighted multi-step task means by sample count;
the table-generation code weighted the tasks equally. The revised vector
plot follows the table's equal-task convention. The recovered task-level
summary CSV confirms the table values.

evidence/results/ contains the 53 original compact CSVs, copied without
changes from the recovered project release. evidence/README.txt explains
their scope. They include invalid/smoke runs for auditability; those are not
used as primary-study results. Raw episode/sample files and checkpoints
remain excluded from the original tracked release.

The main text groups experiments into matched prediction, pilot ablations,
and control tests. Detailed pilot tables are in Appendix A; closed-loop
aggregate and task tables are in Appendix C. Appendix G holds the formal
policy-equivalence definitions and proof. Quantitative plots use unchanged
inputs. Use existing labels for
cross-references; do not type table, figure, or equation numbers manually.
Keep the pilot and matched-study results separate when changing the prose.
Distinguish the evaluated hybrid objective from the proposed extensions.

STYLE AND REVIEW MODE

The official TMLR files are unchanged. Do not edit tmlr.sty or fancyhdr.sty
to change margins, fonts, or spacing. The current main file uses anonymous
review mode. The standard template's 'Under review' header is boilerplate;
this package has not been submitted.

Template source: https://github.com/JmlrOrg/tmlr-style-file
Retrieved: 30 October 2026. LICENSE covers the upstream template files.

This package contains manuscript source, plotting code, original compact
result summaries, and the released implementation with configurations, scripts
and tests. The unmodified implementation files are checksummed. Raw original
experiment outputs and model checkpoints are not included in this package.

Appendix B.5 and B.6 use non-floating placement and reserve space for their
headings and blocks. Appendix C uses the same placement for its algorithm,
configuration and results tables. Keep these pairs together when editing;
ordinary floating can leave subsection headings without their content.

REAL PUSHT WORKED EXAMPLE

figures/pusht_transition_example.pdf uses actual recorded RGB frames and
outputs from a new, limited clean-PushT rerun. It is separate from every
original aggregate table and result CSV. No predicted images are decoded.
The figure applies one independently seeded BC evaluator to three latents:
observed future, VJEPA prediction, and DE-VJEPA prediction. Its means denote
the following action; the recorded input action in panel (a) is distinct.
Contours indicate one standard deviation of the diagonal action Gaussian.
The frames are 96x96 originals, displayed with nearest-neighbor scaling.

To rebuild the figure from the saved data (no retraining required):
  python3 figure_tools/build_pusht_example.py
Requires Python, Matplotlib, NumPy, and Pillow.

figure_data/pusht_example.json contains the policy means, standard
deviations, exact one-transition metrics, and predictor checkpoint hashes.
figure_data/pusht_selection.json records the outcome-independent selection
rule and confirms that episode 7 is held out for seeds 42 and 1000.
figure_data/pusht_provenance.json records pinned revisions and runtime.
figures/pusht_example/ contains the two unmodified RGB frames.

Data source: https://huggingface.co/datasets/lerobot/pusht
Pinned revision: a16737ffb6c8dbe935291b9fd2f36d14c9bf0820 (v2.0).
The dataset card identifies the dataset license as MIT. The MIT license
in this source directory pertains to the TMLR template, as noted above.
The new checkpoints and raw data are retained separately from this small
manuscript source package. The original aggregate experiments, statistical
tests, and intervals have not been regenerated.

FIGURE TYPOGRAPHY

All editable chart labels and diagram text use Latin Modern Roman, matching
the manuscript body. Bold and italic use the corresponding Latin Modern
faces. Mathematical labels use Computer Modern math, matching the paper's
TeX mathematical style. Font size remains adapted to each plot's final size.

figure_tools/figure_style.py centralizes font registration and PDF saving.
The three unmodified OpenType font files are bundled in figure_tools/fonts/
with the GUST Font License. Registration affects only the plotting process;
no OS fonts are installed. Computer Modern math faces come from Matplotlib.
Cairo embeds the OpenType fonts as Type 1C and retains selectable text.

Install the Python plotting dependencies from requirements-figures.txt.
Cairo and fontconfig are also needed as system libraries (fontconfig is
used by Linux). On macOS with Homebrew Cairo, prefix each build command:
  DYLD_FALLBACK_LIBRARY_PATH=/opt/homebrew/lib python3 figure_tools/build_figures.py
Use the same prefix for the other two figure builders.

The former PNGs remain unchanged for provenance and are no longer included
in the compiled paper. appendix_plot_sources.json records the rows used
for the three appendix redraws. No experiments or statistical tests were
rerun for this font change.

METHOD AND IMPLEMENTATION ALIGNMENT

The current title is DE-VJEPA: Decision-Equivalent Latent Prediction for
Policy Fidelity and Control. The archived labels VJEPA and DE-VJEPA remain in tables/plots
for traceability; the empirical claim concerns a point predictor with h=0
and a separately regularized posterior branch. It is not a test of the full
variational bound in Appendix H. The corrected hybrid equation
explicitly separates latent MSE, posterior KL, and frozen-policy KL.

implementation/ contains unmodified released sources, configs, scripts,
tests and pyproject.toml, plus RELEASE_CHECKSUMS.csv and a new loss-path
audit. From that folder, python3 audit_training_path.py verifies hashes and
gradient dependencies using synthetic inputs, with no optimizer steps.
The original release co-locates code and compact results, but original
run-level source identifiers and checkpoints were not recovered. See
Appendix B.3 and figure_data/implementation_provenance.json for this limit.
All 53 original CSVs and the 16 numerical tables remain unchanged.

REGULAR-LENGTH VERSION

The main content is 12 pages, with references beginning on a separate page 13.
Choose Regular submission in OpenReview and leave Beyond PDF empty. The total
PDF is longer because references and appendices are included.

Appendix H retains the full Variational JEPA formulation and extended related
work. Section 2 retains the context needed to read the evaluated method.
Appendix B contains the complete artifact statement. All primary figures,
findings, negative control results, and main limitations remain in the main
text. The DE-VJEPA title, abstract, template fonts and spacing are unchanged.
No experiments were run for this reorganization.
